module.exports={
    connectionstr : 'mongodb+srv://sandeephexbusiness:sandeep123@cluster0.ultbtfz.mongodb.net/agree?retryWrites=true&w=majority'
}